import br.edu.ufersa.SistemaDeLogin.model.DAO.FuncionarioDAO;
import br.edu.ufersa.SistemaDeLogin.model.entities.Funcionario;

public class Main {

    public static void main(String[] args) {

        FuncionarioDAO dao = new FuncionarioDAO();

        dao.salvar(new Funcionario("Joao", "Gerente", "123"));

    }
}